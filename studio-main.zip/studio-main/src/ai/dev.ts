import { config } from 'dotenv';
config();

import '@/ai/flows/automated-expense-categorization.ts';
import '@/ai/flows/bill-payment-automation.ts';
import '@/ai/flows/receipt-data-extraction.ts';
import '@/ai/flows/automatic-expense-categorization.ts';