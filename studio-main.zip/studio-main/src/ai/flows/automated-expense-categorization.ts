'use server';

/**
 * @fileOverview This file contains the Genkit flow for automated expense categorization.
 * It uses AI to categorize expenses and match them with company policies.
 *
 * - automatedExpenseCategorization - A function that handles the expense categorization process.
 * - AutomatedExpenseCategorizationInput - The input type for the automatedExpenseCategorization function.
 * - AutomatedExpenseCategorizationOutput - The return type for the automatedExpenseCategorization function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AutomatedExpenseCategorizationInputSchema = z.object({
  expenseDescription: z
    .string()
    .describe('A description of the expense, including the merchant and amount.'),
  companyPolicies: z
    .string()
    .describe('The company policies regarding expense categorization.'),
});

export type AutomatedExpenseCategorizationInput = z.infer<
  typeof AutomatedExpenseCategorizationInputSchema
>;

const AutomatedExpenseCategorizationOutputSchema = z.object({
  category: z
    .string()
    .describe('The category of the expense, e.g., Travel, Food, Accommodation.'),
  isCompliant: z
    .boolean()
    .describe('Whether the expense is compliant with company policies.'),
  policyViolations: z
    .string()
    .optional()
    .describe('If not compliant, a description of the policy violations.'),
});

export type AutomatedExpenseCategorizationOutput = z.infer<
  typeof AutomatedExpenseCategorizationOutputSchema
>;

export async function automatedExpenseCategorization(
  input: AutomatedExpenseCategorizationInput
): Promise<AutomatedExpenseCategorizationOutput> {
  return automatedExpenseCategorizationFlow(input);
}

const prompt = ai.definePrompt({
  name: 'automatedExpenseCategorizationPrompt',
  input: {schema: AutomatedExpenseCategorizationInputSchema},
  output: {schema: AutomatedExpenseCategorizationOutputSchema},
  prompt: `You are an AI assistant that categorizes expenses and checks them against company policies.

Expense Description: {{{expenseDescription}}}
Company Policies: {{{companyPolicies}}}

Determine the most appropriate category for the expense and whether it complies with the provided company policies.
If the expense is not compliant, explain the policy violations.

Respond in JSON format.
`,
});

const automatedExpenseCategorizationFlow = ai.defineFlow(
  {
    name: 'automatedExpenseCategorizationFlow',
    inputSchema: AutomatedExpenseCategorizationInputSchema,
    outputSchema: AutomatedExpenseCategorizationOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
