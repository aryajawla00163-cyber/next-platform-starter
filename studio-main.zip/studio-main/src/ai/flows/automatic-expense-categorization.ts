'use server';

/**
 * @fileOverview This file contains the Genkit flow for automated expense categorization using receipt data.
 *
 * - categorizeExpense - A function that categorizes expenses based on receipt data.
 * - CategorizeExpenseInput - The input type for the categorizeExpense function.
 * - CategorizeExpenseOutput - The return type for the categorizeExpense function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const CategorizeExpenseInputSchema = z.object({
  receiptDataUri: z
    .string()
    .describe(
      'A photo of a receipt, as a data URI that must include a MIME type and use Base64 encoding. Expected format: \'data:<mimetype>;base64,<encoded_data>\'.' // Corrected the expected format
    ),
  companyPolicies: z
    .string()
    .optional()
    .describe('The company policies regarding expense categorization.'),
});

export type CategorizeExpenseInput = z.infer<typeof CategorizeExpenseInputSchema>;

const CategorizeExpenseOutputSchema = z.object({
  category: z.string().describe('The category of the expense (e.g., Travel, Food, Entertainment).'),
  subCategory: z
    .string()
    .optional()
    .describe('A more granular sub-category of the expense (e.g., Hotel, Restaurant).'),
  amount: z.string().describe('The total amount of the expense (e.g., 12.34).'),
  merchant: z.string().describe('The name of the merchant on the receipt.'),
  date: z.string().describe('The date on the receipt (YYYY-MM-DD).'),
  isCompliant: z
    .boolean()
    .describe('Whether the expense is compliant with company policies, if provided.'),
  policyViolations: z
    .string()
    .optional()
    .describe('If not compliant, a description of the policy violations.'),
});

export type CategorizeExpenseOutput = z.infer<typeof CategorizeExpenseOutputSchema>;

export async function categorizeExpense(
  input: CategorizeExpenseInput
): Promise<CategorizeExpenseOutput> {
  return categorizeExpenseFlow(input);
}

const prompt = ai.definePrompt({
  name: 'categorizeExpensePrompt',
  input: {schema: CategorizeExpenseInputSchema},
  output: {schema: CategorizeExpenseOutputSchema},
  prompt: `You are an AI assistant specializing in categorizing expenses based on receipt data.

You will receive an image of a receipt and, if provided, company policies regarding expense categorization.

You must extract the merchant, date, and amount from the receipt and categorize the expense accordingly.

If company policies are provided, you must also determine whether the expense complies with the policies and, if not, explain the policy violations.

Receipt Image: {{media url=receiptDataUri}}
Company Policies (if provided): {{{companyPolicies}}}

Extract the following information:
Category:
Sub-Category (if applicable):
Amount:
Merchant:
Date:
Is Compliant (if company policies are provided):
Policy Violations (if not compliant and company policies are provided): `,
});

const categorizeExpenseFlow = ai.defineFlow(
  {
    name: 'categorizeExpenseFlow',
    inputSchema: CategorizeExpenseInputSchema,
    outputSchema: CategorizeExpenseOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
