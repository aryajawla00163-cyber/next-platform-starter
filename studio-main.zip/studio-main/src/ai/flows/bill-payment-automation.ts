'use server';

/**
 * @fileOverview An AI agent to automate bill payments by extracting data from uploaded bills and setting up payments according to approval rules.
 *
 * - automateBillPayment - A function that automates the bill payment process.
 * - AutomateBillPaymentInput - The input type for the automateBillPayment function.
 * - AutomateBillPaymentOutput - The return type for the automateBillPayment function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import wav from 'wav';

const AutomateBillPaymentInputSchema = z.object({
  billDataUri: z
    .string()
    .describe(
      "A scanned bill as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  approvalRules: z.string().describe('The approval rules for the bill payment.'),
});
export type AutomateBillPaymentInput = z.infer<typeof AutomateBillPaymentInputSchema>;

const AutomateBillPaymentOutputSchema = z.object({
  extractedData: z.string().describe('The extracted data from the bill.'),
  paymentSetupDetails: z.string().describe('The details of the payment setup.'),
  confirmationMessage: z.string().describe('A confirmation message for the user.'),
});
export type AutomateBillPaymentOutput = z.infer<typeof AutomateBillPaymentOutputSchema>;

export async function automateBillPayment(input: AutomateBillPaymentInput): Promise<AutomateBillPaymentOutput> {
  return automateBillPaymentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'automateBillPaymentPrompt',
  input: {schema: AutomateBillPaymentInputSchema},
  output: {schema: AutomateBillPaymentOutputSchema},
  prompt: `You are an AI assistant that automates bill payments. You extract data from uploaded bills and set up payments according to approval rules.

  Given the following bill:
  {{media url=billDataUri}}

  And the following approval rules: 
  {{approvalRules}}

  Extract all the data from the bill, set up the payment according to the approval rules and provide a confirmation message to the user.
  Include the extracted data, the payment setup details and the confirmation message in the output.

  Follow the following output format strictly:
  {
    "extractedData": "Data extracted from the bill.",
    "paymentSetupDetails": "Details of the payment setup.",
    "confirmationMessage": "A confirmation message for the user."
  }`,
});

const automateBillPaymentFlow = ai.defineFlow(
  {
    name: 'automateBillPaymentFlow',
    inputSchema: AutomateBillPaymentInputSchema,
    outputSchema: AutomateBillPaymentOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
