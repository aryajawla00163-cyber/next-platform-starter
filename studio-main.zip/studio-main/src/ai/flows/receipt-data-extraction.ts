'use server';

/**
 * @fileOverview This file defines a Genkit flow for extracting data (date, amount, merchant) from receipt images using AI/OCR.
 *
 * - `extractReceiptData` -  A function that takes a receipt image as input and returns the extracted data.
 * - `ReceiptDataExtractionInput` - The input type for the `extractReceiptData` function, which is a data URI of the receipt image.
 * - `ReceiptDataExtractionOutput` - The output type for the `extractReceiptData` function, which includes the extracted date, amount, and merchant.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ReceiptDataExtractionInputSchema = z.object({
  receiptDataUri: z
    .string()
    .describe(
      'A photo of a receipt, as a data URI that must include a MIME type and use Base64 encoding. Expected format: \'data:<mimetype>;base64,<encoded_data>\'.' // Corrected the expected format
    ),
});
export type ReceiptDataExtractionInput = z.infer<typeof ReceiptDataExtractionInputSchema>;

const ReceiptDataExtractionOutputSchema = z.object({
  date: z.string().describe('The date on the receipt (YYYY-MM-DD).'),
  amount: z.string().describe('The total amount on the receipt (e.g., 12.34).'),
  merchant: z.string().describe('The name of the merchant on the receipt.'),
});
export type ReceiptDataExtractionOutput = z.infer<typeof ReceiptDataExtractionOutputSchema>;

export async function extractReceiptData(
  input: ReceiptDataExtractionInput
): Promise<ReceiptDataExtractionOutput> {
  return receiptDataExtractionFlow(input);
}

const receiptDataExtractionPrompt = ai.definePrompt({
  name: 'receiptDataExtractionPrompt',
  input: {schema: ReceiptDataExtractionInputSchema},
  output: {schema: ReceiptDataExtractionOutputSchema},
  prompt: `You are an expert AI assistant specializing in extracting data from receipts.  You will receive an image of a receipt and must extract the date, total amount, and merchant name from the receipt.  The date should be formatted as YYYY-MM-DD. The amount should be the total amount, without the currency symbol.

Receipt Image: {{media url=receiptDataUri}}

Extract the following information:
Date: (YYYY-MM-DD)
Amount:
Merchant: `,
});

const receiptDataExtractionFlow = ai.defineFlow(
  {
    name: 'receiptDataExtractionFlow',
    inputSchema: ReceiptDataExtractionInputSchema,
    outputSchema: ReceiptDataExtractionOutputSchema,
  },
  async input => {
    const {output} = await receiptDataExtractionPrompt(input);
    return output!;
  }
);
