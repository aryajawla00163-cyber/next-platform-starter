'use client';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { ShieldAlert } from 'lucide-react';

export default function ApprovalsPage() {

  const renderContent = () => {
    return (
        <TableRow>
            <TableCell colSpan={6} className="text-center h-24 text-muted-foreground">
                No expenses are currently pending approval.
            </TableCell>
        </TableRow>
    );
  }

  return (
    <div className="space-y-8">
        <div>
            <h1 className="text-3xl font-bold font-headline text-primary">Pending Approvals</h1>
            <p className="text-muted-foreground">Review and approve or reject submitted expenses.</p>
        </div>

      <Card>
        <CardHeader>
          <CardTitle>Expense Queue</CardTitle>
          <CardDescription>
            Review expenses pending approval.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="hidden sm:table-cell">Employee</TableHead>
                <TableHead>Merchant</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead className="text-center">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
                {renderContent()}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
