'use client';

import { useState } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PlusCircle, MoreHorizontal, CreditCard as CreditCardIcon, Lock, Unlock, Snowflake } from 'lucide-react';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
  } from '@/components/ui/dropdown-menu';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogFooter,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';

interface CorporateCard {
    id: string;
    last4: string;
    cardholder: string;
    limit: number;
    spent: number;
    status: 'Active' | 'Locked' | 'Frozen';
}

const initialCards: CorporateCard[] = [
    { id: 'card1', last4: '4242', cardholder: 'Jane Doe', limit: 10000, spent: 0, status: 'Active' },
    { id: 'card2', last4: '1121', cardholder: 'Jane Doe', limit: 5000, spent: 0, status: 'Locked' },
    { id: 'card3', last4: '8932', cardholder: 'John Smith', limit: 7500, spent: 0, status: 'Active' },
    { id: 'card4', last4: '5545', cardholder: 'Emily White', limit: 15000, spent: 0, status: 'Frozen' },
];

export default function CardsPage() {
    const [cards, setCards] = useState<CorporateCard[]>(initialCards);
    const [selectedCard, setSelectedCard] = useState<CorporateCard | null>(null);
    const [isAdjustLimitOpen, setIsAdjustLimitOpen] = useState(false);
    const [newLimit, setNewLimit] = useState('');
    const [isIssueCardOpen, setIsIssueCardOpen] = useState(false);
    const [newCard, setNewCard] = useState({ cardholder: '', limit: '' });

    const { toast } = useToast();

    const handleUpdateCardStatus = (cardId: string, status: CorporateCard['status']) => {
        setCards(cards.map(card => card.id === cardId ? { ...card, status } : card));
        toast({
            title: `Card ${status}`,
            description: `The card ending in ${cards.find(c=>c.id === cardId)?.last4} has been ${status.toLowerCase()}.`,
        })
    };

    const handleOpenAdjustLimit = (card: CorporateCard) => {
        setSelectedCard(card);
        setNewLimit(card.limit.toString());
        setIsAdjustLimitOpen(true);
    };

    const handleAdjustLimit = () => {
        if (!selectedCard || !newLimit) return;
        const limitValue = parseFloat(newLimit);
        if (isNaN(limitValue) || limitValue < 0) {
            toast({
                variant: 'destructive',
                title: 'Invalid Limit',
                description: 'Please enter a valid positive number for the limit.',
            });
            return;
        }
        setCards(cards.map(card => card.id === selectedCard.id ? { ...card, limit: limitValue } : card));
        toast({
            title: 'Card Limit Updated',
            description: `The limit for card ending in ${selectedCard.last4} has been set to ₹${limitValue.toLocaleString()}.`,
        })
        setIsAdjustLimitOpen(false);
        setSelectedCard(null);
    };

    const handleIssueNewCard = () => {
        const { cardholder, limit } = newCard;
        const limitValue = parseFloat(limit);
        if (!cardholder || isNaN(limitValue) || limitValue <= 0) {
            toast({
                variant: 'destructive',
                title: 'Invalid Input',
                description: 'Please enter a valid cardholder name and a positive limit.',
            });
            return;
        }

        const newCardData: CorporateCard = {
            id: `card${cards.length + 1}`,
            last4: Math.floor(1000 + Math.random() * 9000).toString(),
            cardholder,
            limit: limitValue,
            spent: 0,
            status: 'Active',
        };

        setCards([...cards, newCardData]);
        toast({
            title: 'Card Issued',
            description: `A new card has been issued to ${cardholder}.`,
        });
        setIsIssueCardOpen(false);
        setNewCard({ cardholder: '', limit: '' });
    };

    return (
        <>
            <div className="space-y-8">
                <div className="flex items-center justify-between">
                    <div>
                        <h1 className="text-3xl font-bold font-headline text-primary">Corporate Cards</h1>
                        <p className="text-muted-foreground">Manage physical and virtual cards for your team.</p>
                    </div>
                    <Button onClick={() => setIsIssueCardOpen(true)}>
                        <PlusCircle className="mr-2 h-4 w-4" />
                        Issue New Card
                    </Button>
                </div>

                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {cards.map((card) => (
                        <Card key={card.id} className="flex flex-col">
                            <CardHeader className='pb-4'>
                                <div className="flex items-start justify-between">
                                    <div>
                                        <CardTitle className="text-lg font-mono">**** **** **** {card.last4}</CardTitle>
                                        <CardDescription>{card.cardholder}</CardDescription>
                                    </div>
                                    <DropdownMenu>
                                        <DropdownMenuTrigger asChild>
                                            <Button variant="ghost" size="icon" className="h-8 w-8">
                                                <MoreHorizontal className="h-4 w-4" />
                                            </Button>
                                        </DropdownMenuTrigger>
                                        <DropdownMenuContent>
                                            <DropdownMenuItem onClick={() => handleOpenAdjustLimit(card)}>Adjust Limit</DropdownMenuItem>
                                            {card.status !== 'Frozen' ? (
                                                <DropdownMenuItem onClick={() => handleUpdateCardStatus(card.id, 'Frozen')}>
                                                    <Snowflake className="mr-2 h-4 w-4" /> Freeze Card
                                                </DropdownMenuItem>
                                            ) : (
                                                <DropdownMenuItem onClick={() => handleUpdateCardStatus(card.id, 'Active')}>
                                                    <Unlock className="mr-2 h-4 w-4" /> Unfreeze Card
                                                </DropdownMenuItem>
                                            )}
                                            {card.status !== 'Locked' ? (
                                                 <DropdownMenuItem className="text-red-500" onClick={() => handleUpdateCardStatus(card.id, 'Locked')}>
                                                    <Lock className="mr-2 h-4 w-4" /> Lock Card
                                                </DropdownMenuItem>
                                            ) : (
                                                <DropdownMenuItem onClick={() => handleUpdateCardStatus(card.id, 'Active')}>
                                                    <Unlock className="mr-2 h-4 w-4" /> Unlock Card
                                                </DropdownMenuItem>
                                            )}
                                        </DropdownMenuContent>
                                    </DropdownMenu>
                                </div>
                            </CardHeader>
                            <CardContent className="flex-grow flex flex-col justify-end">
                                <div className='text-sm text-muted-foreground mb-2'>
                                    Limit: ₹{card.limit.toLocaleString()} / month
                                </div>
                                <div className="w-full bg-muted rounded-full h-2.5 mb-4">
                                    <div className={`h-2.5 rounded-full ${card.status === 'Active' ? 'bg-primary' : 'bg-muted-foreground'}`} style={{ width: `${(card.spent / card.limit) * 100}%` }}></div>
                                </div>
                                <div className="flex justify-between items-center text-sm">
                                    <span className='font-medium'>Spent: ₹{card.spent.toLocaleString()}</span>
                                    <span className={`font-semibold ${
                                        card.status === 'Active' ? 'text-green-600'
                                        : card.status === 'Frozen' ? 'text-blue-600'
                                        : 'text-red-600'}`}>{card.status}</span>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                     <Card className="flex flex-col items-center justify-center border-dashed border-2 hover:border-primary hover:text-primary transition-colors text-muted-foreground">
                        <CardContent className="text-center p-6">
                            <CreditCardIcon className="mx-auto h-12 w-12 mb-4" />
                            <Button variant="outline" onClick={() => setIsIssueCardOpen(true)}>
                                <PlusCircle className="mr-2 h-4 w-4" />
                                Issue a new card
                            </Button>
                        </CardContent>
                    </Card>
                </div>
            </div>
            {/* Adjust Limit Dialog */}
            <Dialog open={isAdjustLimitOpen} onOpenChange={setIsAdjustLimitOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Adjust Spending Limit</DialogTitle>
                        <DialogDescription>
                            Set a new monthly spending limit for the card ending in {selectedCard?.last4}.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="limit" className="text-right">
                                New Limit (₹)
                            </Label>
                            <Input
                                id="limit"
                                type="number"
                                value={newLimit}
                                onChange={(e) => setNewLimit(e.target.value)}
                                className="col-span-3"
                                placeholder="e.g., 5000"
                            />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsAdjustLimitOpen(false)}>Cancel</Button>
                        <Button onClick={handleAdjustLimit}>Save Changes</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

             {/* Issue New Card Dialog */}
            <Dialog open={isIssueCardOpen} onOpenChange={setIsIssueCardOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Issue New Corporate Card</DialogTitle>
                        <DialogDescription>
                            Assign a new virtual or physical card to a team member.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="cardholder" className="text-right">
                                Cardholder
                            </Label>
                            <Input
                                id="cardholder"
                                value={newCard.cardholder}
                                onChange={(e) => setNewCard({ ...newCard, cardholder: e.target.value })}
                                className="col-span-3"
                                placeholder="e.g., John Smith"
                            />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="new-card-limit" className="text-right">
                                Limit (₹)
                            </Label>
                            <Input
                                id="new-card-limit"
                                type="number"
                                value={newCard.limit}
                                onChange={(e) => setNewCard({ ...newCard, limit: e.target.value })}
                                className="col-span-3"
                                placeholder="e.g., 5000"
                            />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsIssueCardOpen(false)}>Cancel</Button>
                        <Button onClick={handleIssueNewCard}>Issue Card</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </>
    );
}
