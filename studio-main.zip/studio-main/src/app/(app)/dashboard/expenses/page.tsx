'use client';

import { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { MoreHorizontal, Trash2, View, Edit } from 'lucide-react';
import { type Expense } from '@/lib/types';
import { useCollection, useUser, useFirestore, useMemoFirebase } from '@/firebase';
import { collection, query, doc, deleteDoc } from 'firebase/firestore';
import { NewExpenseDialog } from '@/components/expenses/NewExpenseDialog';
import { ViewExpenseDialog } from '@/components/expenses/ViewExpenseDialog';
import { toast } from '@/hooks/use-toast';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

async function deleteExpense(db: any, userId: string, expenseId: string) {
    if (!userId) {
        throw new Error('User not authenticated');
    }
    const expenseDocRef = doc(db, 'users', userId, 'expenses', expenseId);
    
    return deleteDoc(expenseDocRef).catch(error => {
        const contextualError = new FirestorePermissionError({
            path: expenseDocRef.path,
            operation: 'delete',
        });
        errorEmitter.emit('permission-error', contextualError);
        throw contextualError; // Re-throw to be caught by the calling function
    });
}

export default function ExpensesPage() {
    const { user } = useUser();
    const firestore = useFirestore();
    const [expenseToDelete, setExpenseToDelete] = useState<Expense | null>(null);
    const [expenseToView, setExpenseToView] = useState<Expense | null>(null);
    const [expenseToEdit, setExpenseToEdit] = useState<Expense | null>(null);

    const expensesQuery = useMemoFirebase(() => {
        if (!user) return null;
        return query(collection(firestore, 'users', user.uid, 'expenses'));
    }, [firestore, user]);

    const { data: expenses, isLoading: expensesLoading } = useCollection<Expense>(expensesQuery);
  
    const handleDelete = async () => {
        if (!expenseToDelete || !user) return;

        try {
            await deleteExpense(firestore, user.uid, expenseToDelete.id);
            toast({
                title: 'Expense Deleted',
                description: 'The expense has been successfully deleted.',
            });
        } catch (error) {
            console.error('Error deleting expense:', error);
            toast({
                variant: 'destructive',
                title: 'Uh oh! Something went wrong.',
                description: 'There was a problem deleting the expense.',
            });
        } finally {
            setExpenseToDelete(null);
        }
    };

    const handleEditClick = (expense: Expense) => {
        setExpenseToEdit(expense);
        // The dialog opening will be handled by the NewExpenseDialog component itself
    }

    const handleExpenseUpdate = () => {
        setExpenseToEdit(null); // Close the dialog by resetting the expense to edit
    }

    return (
      <>
        <div className="space-y-8">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold font-headline text-primary">My Expenses</h1>
                    <p className="text-muted-foreground">View, submit, and manage all your expenses.</p>
                </div>
                <NewExpenseDialog />
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>All Expenses</CardTitle>
                    <CardDescription>A complete list of all your submitted expenses.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                        <TableRow>
                            <TableHead>Merchant</TableHead>
                            <TableHead className="hidden sm:table-cell">Date</TableHead>
                            <TableHead className="hidden md:table-cell">Category</TableHead>
                            <TableHead className="text-right">Amount</TableHead>
                            <TableHead className="text-center">Status</TableHead>
                            <TableHead><span className="sr-only">Actions</span></TableHead>
                        </TableRow>
                        </TableHeader>
                        <TableBody>
                        {expensesLoading ? (
                            <TableRow>
                                <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                                    Loading expenses...
                                </TableCell>
                            </TableRow>
                        ) : expenses && expenses.length > 0 ? expenses.map((expense) => (
                            <TableRow key={expense.id}>
                            <TableCell className="font-medium">{expense.merchant}</TableCell>
                            <TableCell className="hidden sm:table-cell">{new Date(expense.date).toLocaleDateString()}</TableCell>
                            <TableCell className="hidden md:table-cell">{expense.category}</TableCell>
                            <TableCell className="text-right">₹{expense.amount.toFixed(2)}</TableCell>
                            <TableCell className="text-center">
                                <Badge
                                variant={
                                    expense.status === 'Approved'
                                    ? 'default'
                                    : expense.status === 'Pending'
                                    ? 'secondary'
                                    : 'destructive'
                                }
                                className={expense.status === 'Approved' ? 'bg-green-500/20 text-green-700 border-green-500/30' : 
                                            expense.status === 'Pending' ? 'bg-yellow-500/20 text-yellow-700 border-yellow-500/30' :
                                            'bg-red-500/20 text-red-700 border-red-500/30'}
                                >
                                {expense.status}
                                </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                                <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                        <Button variant="ghost" size="icon">
                                            <MoreHorizontal className="h-4 w-4" />
                                        </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent>
                                        <DropdownMenuItem onClick={() => setExpenseToView(expense)}>
                                            <View className="mr-2 h-4 w-4" />
                                            View Details
                                        </DropdownMenuItem>
                                        <NewExpenseDialog expense={expense} onExpenseUpdate={handleExpenseUpdate} />
                                        <DropdownMenuItem
                                            className="text-red-500"
                                            onClick={() => setExpenseToDelete(expense)}
                                        >
                                            <Trash2 className="mr-2 h-4 w-4" />
                                            Delete
                                        </DropdownMenuItem>
                                    </DropdownMenuContent>
                                </DropdownMenu>
                            </TableCell>
                            </TableRow>
                        )) : (
                            <TableRow>
                                <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                                    You have no expenses. Click "New Expense" to get started.
                                </TableCell>
                            </TableRow>
                        )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
        <AlertDialog open={!!expenseToDelete} onOpenChange={(open) => !open && setExpenseToDelete(null)}>
            <AlertDialogContent>
                <AlertDialogHeader>
                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete the expense for
                    <span className='font-bold'> {expenseToDelete?.merchant}</span> of 
                    <span className='font-bold'> ₹{expenseToDelete?.amount.toFixed(2)}</span>.
                </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                    Delete
                </AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
        <ViewExpenseDialog expense={expenseToView} open={!!expenseToView} onOpenChange={(open) => !open && setExpenseToView(null)} />
      </>
    );
  }
