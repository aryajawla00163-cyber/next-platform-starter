'use client';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { DollarSign, Receipt, Clock, CheckCircle } from 'lucide-react';
import { useUser, useCollection, useMemoFirebase } from '@/firebase';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { collection, query } from 'firebase/firestore';
import { useFirestore } from '@/firebase';
import type { Expense } from '@/lib/types';

export default function DashboardPage() {
  const { user, isUserLoading } = useUser();
  const router = useRouter();
  const firestore = useFirestore();

  const expensesQuery = useMemoFirebase(() => {
    if (!user) return null;
    return query(collection(firestore, 'users', user.uid, 'expenses'));
  }, [firestore, user]);

  const { data: expenses, isLoading: expensesLoading } = useCollection<Expense>(expensesQuery);

  const summaryCards = [
    {
      title: "This Month's Spend",
      value: `₹${(expenses?.reduce((sum, e) => sum + e.amount, 0) ?? 0).toFixed(2)}`,
      icon: DollarSign,
      change: 'vs last month',
      changeType: 'neutral',
    },
    {
      title: 'Pending Approvals',
      value: (expenses?.filter(e => e.status === 'Pending').length ?? 0).toString(),
      icon: Clock,
      change: 'items awaiting review',
      changeType: 'neutral',
    },
    {
      title: 'Upcoming Reimbursements',
      value: `₹${(expenses?.filter(e => e.status === 'Approved').reduce((sum, e) => sum + e.amount, 0) ?? 0).toFixed(2)}`,
      icon: Receipt,
      change: 'to be paid',
      changeType: 'neutral',
    },
    {
      title: 'Policy Compliant',
      value: '100%',
      icon: CheckCircle,
      change: 'Keep it up!',
      changeType: 'positive',
    },
  ];

  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push('/login');
    }
  }, [user, isUserLoading, router]);

  if (isUserLoading || !user) {
    return null; // or a loading spinner
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold font-headline text-primary">Dashboard</h1>
        <p className="text-muted-foreground">Welcome back, {user.email}! Here's a summary of your account.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {summaryCards.map((item) => (
          <Card key={item.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{item.title}</CardTitle>
              <item.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{item.value}</div>
              <p
                className={`text-xs text-muted-foreground ${
                  item.changeType === 'positive' ? 'text-green-600' : ''
                }`}
              >
                {item.change}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
          <CardDescription>
            Your 5 most recent expenses.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Merchant</TableHead>
                <TableHead className="hidden sm:table-cell">Date</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead className="text-center">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {expensesLoading ? (
                 <TableRow>
                    <TableCell colSpan={4} className="h-24 text-center text-muted-foreground">
                        Loading transactions...
                    </TableCell>
                </TableRow>
              ) : expenses && expenses.length > 0 ? (
                expenses.slice(0, 5).map((expense) => (
                  <TableRow key={expense.id}>
                    <TableCell className="font-medium">{expense.merchant}</TableCell>
                    <TableCell className="hidden sm:table-cell">{new Date(expense.date).toLocaleDateString()}</TableCell>
                    <TableCell className="text-right">₹{expense.amount.toFixed(2)}</TableCell>
                    <TableCell className="text-center">
                      <Badge
                        variant={
                          expense.status === 'Approved'
                            ? 'default'
                            : expense.status === 'Pending'
                            ? 'secondary'
                            : 'destructive'
                        }
                        className={expense.status === 'Approved' ? 'bg-green-500/20 text-green-700 border-green-500/30' : 
                                    expense.status === 'Pending' ? 'bg-yellow-500/20 text-yellow-700 border-yellow-500/30' :
                                    'bg-red-500/20 text-red-700 border-red-500/30'}
                      >
                        {expense.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={4} className="h-24 text-center text-muted-foreground">
                    No recent transactions.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
