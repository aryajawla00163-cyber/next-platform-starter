import { Logo } from "@/components/Logo";

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-muted/50 p-4">
        <div className="absolute top-8 left-8">
            <Logo />
        </div>
      {children}
    </div>
  );
}
