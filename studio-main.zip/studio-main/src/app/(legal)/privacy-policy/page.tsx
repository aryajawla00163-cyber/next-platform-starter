import Link from "next/link";
import { APP_NAME } from "@/lib/constants";

export default function PrivacyPolicyPage() {
  return (
    <>
      <h1>Privacy Policy for {APP_NAME}</h1>
      <p>Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
      
      <p>Welcome to {APP_NAME}. We are committed to protecting your privacy and handling your data in an open and transparent manner. This privacy policy sets out how we collect, use, and protect any information that you give us when you use this website and our services.</p>

      <h2>1. Information We Collect</h2>
      <p>We may collect the following information:</p>
      <ul>
        <li><strong>Personal Identification Information:</strong> Name, email address, phone number, etc., when you register for an account.</li>
        <li><strong>Financial Data:</strong> Information from receipts, invoices, and other financial documents you upload, such as merchant names, transaction dates, and amounts. We do not store full credit card numbers.</li>
        <li><strong>Technical Data:</strong> IP address, browser type and version, time zone setting and location, browser plug-in types and versions, operating system and platform, and other technology on the devices you use to access this website.</li>
        <li><strong>Usage Data:</strong> Information about how you use our website, products, and services.</li>
      </ul>

      <h2>2. How We Use Your Information</h2>
      <p>We use the information we collect to:</p>
      <ul>
        <li>Provide, operate, and maintain our services.</li>
        <li>Improve, personalize, and expand our services.</li>
        <li>Understand and analyze how you use our services.</li>
        <li>Develop new products, services, features, and functionality.</li>
        <li>Communicate with you, either directly or through one of our partners, for customer service, to provide you with updates and other information relating to the website, and for marketing purposes.</li>
        <li>Process your transactions and manage your expense reports.</li>
        <li>Find and prevent fraud.</li>
      </ul>

      <h2>3. Data Security</h2>
      <p>We are committed to ensuring that your information is secure. In order to prevent unauthorized access or disclosure, we have put in place suitable physical, electronic, and managerial procedures to safeguard and secure the information we collect online. All financial data you upload is encrypted both in transit and at rest.</p>

      <h2>4. Your Data Protection Rights</h2>
      <p>Depending on your location, you may have the following rights regarding your personal data:</p>
      <ul>
        <li>The right to access – You have the right to request copies of your personal data.</li>
        <li>The right to rectification – You have the right to request that we correct any information you believe is inaccurate.</li>
        <li>The right to erasure – You have the right to request that we erase your personal data, under certain conditions.</li>
      </ul>

      <h2>5. Changes to This Policy</h2>
      <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page. You are advised to review this Privacy Policy periodically for any changes.</p>

      <h2>Contact Us</h2>
      <p>If you have any questions about this Privacy Policy, please <Link href="/contact">contact us</Link>.</p>
    </>
  );
}
