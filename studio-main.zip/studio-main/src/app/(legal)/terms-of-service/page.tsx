import Link from "next/link";
import { APP_NAME } from "@/lib/constants";

export default function TermsOfServicePage() {
  return (
    <>
      <h1>Terms of Service for {APP_NAME}</h1>
      <p>Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>

      <p>Please read these Terms of Service ("Terms", "Terms of Service") carefully before using the {APP_NAME} website and mobile application (the "Service") operated by {APP_NAME} ("us", "we", or "our").</p>

      <p>Your access to and use of the Service is conditioned upon your acceptance of and compliance with these Terms. These Terms apply to all visitors, users, and others who wish to access or use the Service.</p>

      <h2>1. Accounts</h2>
      <p>When you create an account with us, you guarantee that you are above the age of 18, and that the information you provide us is accurate, complete, and current at all times. Inaccurate, incomplete, or obsolete information may result in the immediate termination of your account on the Service.</p>
      <p>You are responsible for maintaining the confidentiality of your account and password, including but not limited to the restriction of access to your computer and/or account. You agree to accept responsibility for any and all activities or actions that occur under your account and/or password.</p>

      <h2>2. Intellectual Property</h2>
      <p>The Service and its original content (excluding Content provided by users), features, and functionality are and will remain the exclusive property of {APP_NAME} and its licensors. The Service is protected by copyright, trademark, and other laws of both the United States and foreign countries. Our trademarks and trade dress may not be used in connection with any product or service without the prior written consent of {APP_NAME}.</p>

      <h2>3. User Content</h2>
      <p>Our Service allows you to post, link, store, share and otherwise make available certain information, text, graphics, videos, or other material ("Content"). You are responsible for the Content that you post on or through the Service, including its legality, reliability, and appropriateness.</p>
      <p>By posting Content on or through the Service, You represent and warrant that: (i) the Content is yours (you own it) and/or you have the right to use it and the right to grant us the rights and license as provided in these Terms, and (ii) that the posting of your Content on or through the Service does not violate the privacy rights, publicity rights, copyrights, contract rights or any other rights of any person or entity.</p>

      <h2>4. Termination</h2>
      <p>We may terminate or suspend your account and bar access to the Service immediately, without prior notice or liability, under our sole discretion, for any reason whatsoever and without limitation, including but not limited to a breach of the Terms.</p>
      
      <h2>5. Limitation Of Liability</h2>
      <p>In no event shall {APP_NAME}, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Service.</p>

      <h2>6. Governing Law</h2>
      <p>These Terms shall be governed and construed in accordance with the laws of the State of Delaware, United States, without regard to its conflict of law provisions.</p>
      
      <h2>Contact Us</h2>
      <p>If you have any questions about these Terms, please <Link href="/contact">contact us</Link>.</p>
    </>
  );
}
