import Image from "next/image";
import { PlaceHolderImages } from "@/lib/placeholder-images";

const teamMembers = [
  { name: 'Alice Johnson', role: 'CEO & Co-Founder', imageId: 'team-member-1' },
  { name: 'Bob Williams', role: 'CTO & Co-Founder', imageId: 'team-member-2' },
  { name: 'Charlie Brown', role: 'Head of Product', imageId: 'team-member-3' },
  { name: 'Diana Miller', role: 'Head of Design', imageId: 'team-member-4' },
]

export default function AboutPage() {
  return (
    <div className="py-12 sm:py-16 lg:py-20">
      <div className="container max-w-4xl mx-auto text-center">
        <h1 className="text-4xl sm:text-5xl font-headline font-bold text-primary tracking-tight">
          Our Mission: Simplify Finance for Everyone
        </h1>
        <p className="mt-6 text-lg text-foreground/80">
          We started TrackYourWallet to eliminate the friction in company spending. Our goal is to give finance teams real-time visibility and control, while making expense reporting a breeze for employees. We believe that by automating the tedious parts of finance, we can empower businesses to focus on what they do best.
        </p>

        <div className="mt-16">
            <h2 className="text-3xl font-headline font-bold text-primary tracking-tight">Meet the Team</h2>
            <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-8">
                {teamMembers.map(member => {
                    const image = PlaceHolderImages.find(p => p.id === member.imageId);
                    if (!image) return null;

                    return (
                        <div key={member.name}>
                           <Image
                                src={image.imageUrl}
                                alt={member.name}
                                width={128}
                                height={128}
                                className="rounded-full mx-auto shadow-lg aspect-square object-cover"
                                data-ai-hint={image.imageHint}
                            />
                            <h3 className="mt-4 text-lg font-semibold font-headline text-primary">{member.name}</h3>
                            <p className="text-sm text-muted-foreground">{member.role}</p>
                        </div>
                    )
                })}
            </div>
        </div>
      </div>
    </div>
  );
}
