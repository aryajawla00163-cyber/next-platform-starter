import { HeroSection } from '@/components/home/HeroSection';
import { SocialProof } from '@/components/home/SocialProof';
import { FeatureGrid } from '@/components/home/FeatureGrid';
import { HowItWorks } from '@/components/home/HowItWorks';
import { Testimonials } from '@/components/home/Testimonials';
import { Integrations } from '@/components/home/Integrations';
import { FaqSection } from '@/components/home/FaqSection';
import { FinalCta } from '@/components/home/FinalCta';

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <SocialProof />
      <FeatureGrid />
      <HowItWorks />
      <Testimonials />
      <Integrations />
      <FaqSection />
      <FinalCta />
    </>
  );
}
