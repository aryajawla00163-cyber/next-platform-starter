import { Check } from 'lucide-react';
import Link from 'next/link';

import { Button } from '@/components/ui/button';
import { PRICING_TIERS } from '@/lib/constants';
import { cn } from '@/lib/utils';
import { FaqSection } from '@/components/home/FaqSection';

export default function PricingPage() {
  return (
    <>
      <div className="py-12 sm:py-16 lg:py-20">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl font-headline font-bold text-primary tracking-tight">
              Pricing that scales with you
            </h1>
            <p className="mt-4 text-lg text-foreground/80">
              Choose the plan that's right for your business. Start for free and upgrade as you grow.
            </p>
          </div>

          <div className="mt-12 grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-5xl mx-auto items-start">
            {PRICING_TIERS.map((tier) => (
              <div
                key={tier.name}
                className={cn(
                  'rounded-xl border shadow-sm p-8 flex flex-col h-full bg-card',
                  tier.isPopular ? 'border-primary ring-2 ring-primary shadow-2xl' : 'border-border'
                )}
              >
                {tier.isPopular && (
                  <div className="text-center">
                    <div className="inline-flex items-center rounded-full bg-primary px-4 py-1 text-sm font-semibold text-primary-foreground">
                      Most Popular
                    </div>
                  </div>
                )}
                <div className="mt-4 text-center">
                  <h3 className="text-2xl font-bold font-headline text-primary">{tier.name}</h3>
                  <div className="mt-2 flex items-baseline justify-center gap-x-2">
                    <span className="text-4xl font-bold tracking-tight text-foreground">{tier.price}</span>
                    {tier.price !== 'Free' && tier.price !== 'Custom' && <span className="text-sm font-semibold leading-6 tracking-wide text-muted-foreground">/mo</span>}
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{tier.priceDetail}</p>
                </div>

                <div className="my-8 h-px w-full bg-border" />

                <ul role="list" className="space-y-4 text-sm leading-6 text-foreground/80 flex-grow">
                  {tier.features.map((feature) => (
                    <li key={feature} className="flex gap-x-3">
                      <Check className="h-6 w-5 flex-none text-accent" aria-hidden="true" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <Button
                  asChild
                  size="lg"
                  className={cn('mt-8 w-full', !tier.isPopular && 'bg-primary/90 hover:bg-primary')}
                >
                  <Link href={tier.ctaHref}>{tier.cta}</Link>
                </Button>
              </div>
            ))}
          </div>
        </div>
      </div>
      <FaqSection />
    </>
  );
}
