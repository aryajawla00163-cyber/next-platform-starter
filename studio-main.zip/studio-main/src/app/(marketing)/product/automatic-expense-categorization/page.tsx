import { AutomaticExpenseCategorizationDemo } from '@/components/product/AutomaticExpenseCategorizationDemo';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

export default function AutomaticExpenseCategorizationPage() {
  return (
    <div className="py-12 sm:py-16 lg:py-20">
      <div className="container max-w-6xl mx-auto">
        <div className="text-center">
          <h1 className="text-4xl sm:text-5xl font-headline font-bold text-primary tracking-tight">
            AI-Powered Categorization & Compliance
          </h1>
          <p className="mt-6 mx-auto max-w-3xl text-lg text-foreground/80">
            Stop wasting time on manual data entry and policy checks. Our AI engine instantly extracts data from any receipt, assigns the correct expense category, and flags any policy violations, ensuring compliance and freeing up your team for more strategic work.
          </p>
        </div>
        
        <div className="mt-12">
            <AutomaticExpenseCategorizationDemo />
        </div>

        <div className="mt-12 text-center">
          <Button size="lg" asChild>
            <Link href="/signup">Automate Your Expenses Free</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
