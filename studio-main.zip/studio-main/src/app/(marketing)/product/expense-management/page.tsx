import Image from "next/image";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function ExpenseManagementPage() {
    const mockup = PlaceHolderImages.find(p => p.id === 'expense-report-mockup');
    return (
        <div className="py-12 sm:py-16 lg:py-20">
            <div className="container max-w-5xl mx-auto">
                <div className="text-center">
                    <h1 className="text-4xl sm:text-5xl font-headline font-bold text-primary tracking-tight">
                        Automated Expense Management
                    </h1>
                    <p className="mt-6 mx-auto max-w-2xl text-lg text-foreground/80">
                        Capture expenses, automatically generate reports, and get a clear view of your spending with our powerful expense management tools.
                    </p>
                </div>
                {mockup && (
                    <div className="mt-12">
                        <Image
                            src={mockup.imageUrl}
                            alt={mockup.description}
                            width={1200}
                            height={600}
                            className="rounded-xl shadow-2xl ring-1 ring-border/20"
                            data-ai-hint={mockup.imageHint}
                        />
                    </div>
                )}
                 <div className="mt-12 text-center">
                    <Button size="lg" asChild>
                        <Link href="/signup">Start Tracking Expenses</Link>
                    </Button>
                </div>
            </div>
        </div>
    );
}
