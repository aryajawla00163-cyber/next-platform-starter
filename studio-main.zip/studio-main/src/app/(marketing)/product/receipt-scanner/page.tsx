import Image from "next/image";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function ReceiptScannerPage() {
    const mockup = PlaceHolderImages.find(p => p.id === 'receipt-scanner-mockup');
    return (
        <div className="py-12 sm:py-16 lg:py-20">
            <div className="container max-w-5xl mx-auto">
                 <div className="grid lg:grid-cols-2 gap-12 items-center">
                    <div>
                        <h1 className="text-4xl sm:text-5xl font-headline font-bold text-primary tracking-tight">
                            Snap a receipt, we do the rest.
                        </h1>
                        <p className="mt-6 text-lg text-foreground/80">
                            Our AI-powered OCR technology reads and understands any receipt instantly. It extracts the merchant, date, and amount, then automatically categorizes the expense, saving you from manual data entry.
                        </p>
                         <div className="mt-8">
                            <Button size="lg" asChild>
                                <Link href="/signup">Try the Scanner Free</Link>
                            </Button>
                        </div>
                    </div>
                     {mockup && (
                        <div className="flex justify-center">
                            <Image
                                src={mockup.imageUrl}
                                alt={mockup.description}
                                width={400}
                                height={800}
                                className="rounded-2xl shadow-2xl ring-1 ring-border/20"
                                data-ai-hint={mockup.imageHint}
                            />
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
