import Link from 'next/link';
import { Wallet } from 'lucide-react';
import { cn } from '@/lib/utils';
import { APP_NAME } from '@/lib/constants';

export function Logo({ className }: { className?: string }) {
  return (
    <Link href="/" className={cn("flex items-center gap-2", className)}>
      <Wallet className="h-7 w-7 text-primary" />
      <span className="text-xl font-bold font-headline tracking-tight text-primary">{APP_NAME}</span>
    </Link>
  );
}
