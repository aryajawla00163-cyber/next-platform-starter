'use client';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { type Expense } from '@/lib/types';
import { format } from 'date-fns';
import { Badge } from '../ui/badge';

export function ViewExpenseDialog({ expense, open, onOpenChange }: { expense: Expense | null; open: boolean; onOpenChange: (open: boolean) => void; }) {
  if (!expense) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[480px]">
        <DialogHeader>
          <DialogTitle>Expense Details</DialogTitle>
          <DialogDescription>
            Viewing details for the expense at {expense.merchant}.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4 text-sm">
            <div className="flex justify-between items-center">
                <span className="font-medium text-muted-foreground">Merchant</span>
                <span className="font-semibold">{expense.merchant}</span>
            </div>
            <div className="flex justify-between items-center">
                <span className="font-medium text-muted-foreground">Amount</span>
                <span className="font-semibold">₹{expense.amount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
                <span className="font-medium text-muted-foreground">Date</span>
                <span className="font-semibold">{format(new Date(expense.date), 'PPP')}</span>
            </div>
            <div className="flex justify-between items-center">
                <span className="font-medium text-muted-foreground">Category</span>
                <span className="font-semibold">{expense.category}</span>
            </div>
            <div className="flex justify-between items-center">
                <span className="font-medium text-muted-foreground">Status</span>
                 <Badge
                    variant={
                        expense.status === 'Approved'
                        ? 'default'
                        : expense.status === 'Pending'
                        ? 'secondary'
                        : 'destructive'
                    }
                    className={expense.status === 'Approved' ? 'bg-green-500/20 text-green-700 border-green-500/30' : 
                                expense.status === 'Pending' ? 'bg-yellow-500/20 text-yellow-700 border-yellow-500/30' :
                                'bg-red-500/20 text-red-700 border-red-500/30'}
                >
                    {expense.status}
                </Badge>
            </div>
            {expense.description && (
                 <div className="flex flex-col space-y-2 pt-2">
                    <span className="font-medium text-muted-foreground">Description</span>
                    <p className="p-3 bg-muted/50 rounded-md border text-foreground/80">{expense.description}</p>
                </div>
            )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
