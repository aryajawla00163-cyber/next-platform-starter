import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FEATURE_GRID_ITEMS } from '@/lib/constants';

export function FeatureGrid() {
  return (
    <section className="py-12 sm:py-16 lg:py-20 bg-muted/50">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-headline font-bold text-primary tracking-tight">
            Everything you need to control spend
          </h2>
          <p className="mt-4 text-lg text-foreground/80">
            From corporate cards and expense reports to invoicing and bill pay, we've got you covered. One platform to manage it all.
          </p>
        </div>
        <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {FEATURE_GRID_ITEMS.map((feature) => (
            <Card key={feature.title} className="bg-card/50 hover:bg-card/90 transition-colors shadow-sm hover:shadow-lg">
              <CardHeader>
                <div className="bg-primary/10 text-primary h-12 w-12 rounded-lg flex items-center justify-center">
                  <feature.icon className="h-6 w-6" />
                </div>
              </CardHeader>
              <CardContent>
                <CardTitle className="text-lg font-headline font-semibold text-primary">
                  {feature.title}
                </CardTitle>
                <p className="mt-2 text-sm text-foreground/70">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
