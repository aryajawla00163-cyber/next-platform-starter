import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export function FinalCta() {
  return (
    <section className="py-12 sm:py-16 lg:py-20">
      <div className="container">
        <div className="bg-primary text-primary-foreground rounded-xl p-8 md:p-12 lg:p-16 text-center">
          <h2 className="text-3xl sm:text-4xl font-headline font-bold tracking-tight">
            Ready to simplify your spending?
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-lg text-primary-foreground/80">
            Join thousands of companies that trust TrackYourWallet to manage their expenses, and get back to focusing on what matters most: growing your business.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row max-w-md mx-auto items-center justify-center gap-4">
              <form className="w-full sm:w-auto flex-grow sm:flex-grow-0 flex items-center gap-2">
                <Input
                  type="email"
                  placeholder="Your work email"
                  className="w-full sm:w-64 bg-primary-foreground/10 text-primary-foreground border-primary-foreground/20 placeholder:text-primary-foreground/60 focus:bg-primary-foreground/20"
                  aria-label="Email for getting started"
                />
                <Button type="submit" size="lg" variant="secondary" className="bg-accent text-accent-foreground hover:bg-accent/90">Get Started Free</Button>
              </form>
            </div>
        </div>
      </div>
    </section>
  );
}
