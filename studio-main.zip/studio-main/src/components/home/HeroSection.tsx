import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PlaceHolderImages } from '@/lib/placeholder-images';

export function HeroSection() {
  const dashboardMockup = PlaceHolderImages.find(p => p.id === 'dashboard-mockup');

  return (
    <section className="py-12 sm:py-16 lg:py-20 xl:py-24">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-headline font-bold text-primary tracking-tighter">
              Spend smart. Close faster.
              <br />
              All on one platform.
            </h1>
            <p className="mt-6 max-w-xl mx-auto lg:mx-0 text-lg text-foreground/80">
              Say goodbye to expense reports, endless receipt chasing, and manual data entry. TrackYourWallet automates your entire spend process in one place.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
              <form className="w-full sm:w-auto flex-grow sm:flex-grow-0 flex items-center gap-2">
                <Input
                  type="email"
                  placeholder="Enter your email"
                  className="w-full sm:w-64 bg-background"
                  aria-label="Email for getting started"
                />
                <Button type="submit" size="lg">Get Started Free</Button>
              </form>
            </div>
             <Button variant="link" asChild className="mt-2 text-muted-foreground">
                <Link href="/contact">Book a Demo</Link>
             </Button>
          </div>
          <div className="w-full h-auto">
            {dashboardMockup && (
              <Image
                src={dashboardMockup.imageUrl}
                alt={dashboardMockup.description}
                width={1200}
                height={900}
                className="rounded-xl shadow-2xl ring-1 ring-border/20"
                data-ai-hint={dashboardMockup.imageHint}
                priority
              />
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
