import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { HOW_IT_WORKS_TABS } from '@/lib/constants';

export function HowItWorks() {
  return (
    <section className="py-12 sm:py-16 lg:py-20">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-headline font-bold text-primary tracking-tight">
            Designed for every role on your team
          </h2>
          <p className="mt-4 text-lg text-foreground/80">
            A seamless experience for everyone, from the employee on the go to the CFO in the boardroom.
          </p>
        </div>
        <Tabs defaultValue={HOW_IT_WORKS_TABS[0].title} className="mt-12">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-3">
            {HOW_IT_WORKS_TABS.map((tab) => (
              <TabsTrigger key={tab.title} value={tab.title}>
                {tab.title}
              </TabsTrigger>
            ))}
          </TabsList>

          {HOW_IT_WORKS_TABS.map((tab) => (
            <TabsContent key={tab.title} value={tab.title}>
              <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-8">
                {tab.steps.map((step) => (
                  <div key={step.number} className="relative">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xl font-bold font-headline">
                        {step.number}
                      </div>
                      <div className="flex-grow border-t-2 border-border ml-4"></div>
                    </div>
                    <div className="mt-4 ml-2">
                      <h3 className="text-lg font-headline font-semibold text-primary">{step.title}</h3>
                      <p className="mt-2 text-sm text-foreground/70">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  );
}
