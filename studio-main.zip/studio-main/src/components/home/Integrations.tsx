import { INTEGRATION_LOGOS } from '@/lib/constants';

export function Integrations() {
  return (
    <section className="py-12 sm:py-16 lg:py-20">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-headline font-bold text-primary tracking-tight">
            Works with your finance stack
          </h2>
          <p className="mt-4 text-lg text-foreground/80">
            TrackYourWallet seamlessly integrates with the accounting, HR, and ERP systems you already use, making your workflow smoother than ever.
          </p>
        </div>
        <div className="mt-12 flex justify-center items-center flex-wrap gap-x-12 gap-y-8">
          {INTEGRATION_LOGOS.map((logo) => (
            <div key={logo.name} className="flex items-center gap-3 text-muted-foreground hover:text-foreground transition-colors">
              <logo.icon className="h-8 w-8" />
              <span className="text-lg font-semibold font-headline">{logo.name}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
