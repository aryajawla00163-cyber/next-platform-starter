import { COMPANY_LOGOS } from '@/lib/constants';
import { CompanyPlaceholderLogo } from '@/components/icons/CompanyPlaceholderLogo';

export function SocialProof() {
  return (
    <section className="py-12 sm:py-16">
      <div className="container">
        <div className="text-center">
          <p className="text-sm font-semibold text-muted-foreground tracking-wider uppercase">
            Trusted by thousands of teams worldwide
          </p>
          <div className="mt-6 flex justify-center items-center flex-wrap gap-x-8 gap-y-4">
            {COMPANY_LOGOS.map((logo) => (
              <CompanyPlaceholderLogo key={logo.name} className="h-8" text={logo.name} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
