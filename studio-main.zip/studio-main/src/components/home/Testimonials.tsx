import Image from 'next/image';
import { Card, CardContent } from '@/components/ui/card';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '@/components/ui/carousel';
import { TESTIMONIALS } from '@/lib/constants';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Star } from 'lucide-react';

export function Testimonials() {
  return (
    <section className="py-12 sm:py-16 lg:py-20 bg-muted/50">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-headline font-bold text-primary tracking-tight">
            Loved by modern finance teams
          </h2>
          <p className="mt-4 text-lg text-foreground/80">
            Don't just take our word for it. Hear what our customers have to say about simplifying their spend management.
          </p>
        </div>

        <Carousel
          opts={{
            align: 'start',
            loop: true,
          }}
          className="w-full mt-12"
        >
          <CarouselContent>
            {TESTIMONIALS.map((testimonial, index) => {
              const avatar = PlaceHolderImages.find(p => p.id === testimonial.avatarId);
              if (!avatar) return null;

              return (
                <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/3">
                  <div className="p-1 h-full">
                    <Card className="h-full flex flex-col justify-between shadow-lg">
                        <CardContent className="p-6">
                            <div className="flex text-yellow-400 gap-0.5 mb-4">
                                {[...Array(5)].map((_, i) => <Star key={i} className="h-5 w-5 fill-current" />)}
                            </div>
                            <blockquote className="text-base text-foreground/80">
                                "{testimonial.quote}"
                            </blockquote>
                        </CardContent>
                        <div className="p-6 bg-muted/50 flex items-center gap-4">
                            <Image
                                src={avatar.imageUrl}
                                alt={testimonial.name}
                                width={48}
                                height={48}
                                className="rounded-full aspect-square object-cover"
                                data-ai-hint={avatar.imageHint}
                            />
                            <div>
                                <p className="font-semibold font-headline text-primary">{testimonial.name}</p>
                                <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                            </div>
                        </div>
                    </Card>
                  </div>
                </CarouselItem>
              );
            })}
          </CarouselContent>
          <CarouselPrevious className="hidden lg:inline-flex" />
          <CarouselNext className="hidden lg:inline-flex" />
        </Carousel>
      </div>
    </section>
  );
}
