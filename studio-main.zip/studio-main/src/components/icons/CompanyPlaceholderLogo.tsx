import { cn } from "@/lib/utils";

export const CompanyPlaceholderLogo = ({
  className,
  ...props
}: React.SVGProps<SVGSVGElement> & { text?: string }) => (
  <div
    className={cn(
      "flex items-center justify-center gap-2 text-muted-foreground font-semibold font-headline text-lg",
      className
    )}
  >
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="text-muted-foreground/50"
    >
      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5" />
      <path
        d="M7.5 12C9.5 10 14.5 10 16.5 12"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
    </svg>
    <span>{props.text || "Company"}</span>
  </div>
);
