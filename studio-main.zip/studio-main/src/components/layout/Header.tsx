
"use client";

import * as React from "react";
import Link from "next/link";
import { Menu, X } from "lucide-react";

import { NAV_LINKS, APP_NAME } from "@/lib/constants";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Logo } from "../Logo";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "../ui/accordion";

export function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 max-w-screen-2xl items-center justify-between">
        <Logo />

        {/* Desktop Navigation */}
        <NavigationMenu className="hidden md:flex">
          <NavigationMenuList>
            {NAV_LINKS.map((navItem) =>
              navItem.items ? (
                <NavigationMenuItem key={navItem.title}>
                  <NavigationMenuTrigger>{navItem.title}</NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className={cn("grid w-[400px] gap-3 p-4", navItem.items.length > 4 ? "md:w-[500px] md:grid-cols-2" : "md:w-[400px]")}>
                      {navItem.items.map((item) => (
                        <ListItem key={item.title} title={item.title} href={item.href} icon={item.icon}>
                          {item.description}
                        </ListItem>
                      ))}
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>
              ) : (
                <NavigationMenuItem key={navItem.title}>
                  <Link href={navItem.href} passHref>
                    <NavigationMenuLink asChild className={navigationMenuTriggerStyle()}>
                      <a>{navItem.title}</a>
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
              )
            )}
          </NavigationMenuList>
        </NavigationMenu>

        {/* Mobile Navigation */}
        <div className="md:hidden">
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Open menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-full pr-0">
              <div className="flex justify-between items-center py-2 pr-6">
                <Logo />
                 <SheetTrigger asChild>
                    <Button variant="ghost" size="icon">
                        <X className="h-6 w-6" />
                        <span className="sr-only">Close menu</span>
                    </Button>
                </SheetTrigger>
              </div>
              <div className="mt-6 flow-root">
                <div className="-my-6 divide-y divide-border">
                  <div className="space-y-2 py-6 px-6">
                    <Accordion type="single" collapsible className="w-full">
                    {NAV_LINKS.map((navItem) =>
                      !navItem.items ? (
                        <Link
                          key={navItem.title}
                          href={navItem.href}
                          className="-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-foreground hover:bg-muted"
                          onClick={() => setIsMobileMenuOpen(false)}
                        >
                          {navItem.title}
                        </Link>
                      ) : (
                        <AccordionItem value={navItem.title} className="border-b-0" key={navItem.title}>
                          <AccordionTrigger className="-mx-3 rounded-lg px-3 py-2 text-base font-semibold leading-7 text-foreground hover:bg-muted [&[data-state=open]]:bg-muted">
                            {navItem.title}
                          </AccordionTrigger>
                          <AccordionContent className="pb-0">
                            <div className="mt-2 space-y-2">
                            {navItem.items.map((item) => (
                              <Link
                                key={item.title}
                                href={item.href}
                                className="block rounded-lg py-2 pl-6 pr-3 text-sm leading-7 text-muted-foreground hover:bg-muted hover:text-foreground"
                                onClick={() => setIsMobileMenuOpen(false)}
                              >
                                {item.title}
                              </Link>
                            ))}
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      )
                    )}
                    </Accordion>
                  </div>
                  <div className="py-6 px-6">
                    <Link
                      href="/login"
                      className="-mx-3 block rounded-lg px-3 py-2.5 text-base font-semibold leading-7 text-foreground hover:bg-muted"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      Log in
                    </Link>
                     <Button asChild className="w-full mt-4">
                        <Link href="/signup" onClick={() => setIsMobileMenuOpen(false)}>Get Started Free</Link>
                    </Button>
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>

        <div className="hidden md:flex items-center gap-2">
          <Button variant="ghost" asChild>
            <Link href="/login">Log In</Link>
          </Button>
          <Button asChild>
            <Link href="/signup">Get Started Free</Link>
          </Button>
        </div>
      </div>
    </header>
  );
}

const ListItem = React.forwardRef<React.ElementRef<'a'>, React.ComponentPropsWithoutRef<'a'> & { icon?: React.ElementType }>(
  ({ className, title, children, icon: Icon, ...props }, ref) => {
    return (
      <li>
        <NavigationMenuLink asChild>
          <a
            ref={ref}
            className={cn(
              'block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground',
              className
            )}
            {...props}
          >
            <div className="flex items-center gap-2 text-sm font-medium leading-none">
              {Icon && <Icon className="h-4 w-4 text-primary" />}
              {title}
            </div>
            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">{children}</p>
          </a>
        </NavigationMenuLink>
      </li>
    );
  }
);
ListItem.displayName = 'ListItem';
