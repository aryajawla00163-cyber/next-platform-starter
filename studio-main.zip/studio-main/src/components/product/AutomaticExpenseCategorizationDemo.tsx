"use client";

import { useState } from 'react';
import Image from 'next/image';
import { categorizeExpense, type CategorizeExpenseOutput } from '@/ai/flows/automatic-expense-categorization';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, AlertTriangle, Bot } from 'lucide-react';

const sampleReceipts = [
  { id: 'receipt-demo-coffee', name: 'Coffee Receipt' },
  { id: 'receipt-demo-taxi', name: 'Taxi Receipt' },
  { id: 'receipt-demo-hotel', name: 'Hotel Bill' },
];

const defaultPolicies = `Expense Policy:
- Meals are limited to ₹4000 per person.
- Alcohol is not reimbursed.
- Flights must be coach class.
- Hotels are capped at ₹25000/night.`;

async function handleCategorization(imageId: string, policies: string): Promise<{ success: boolean, data?: CategorizeExpenseOutput, error?: string }> {
    "use server";
    
    const image = PlaceHolderImages.find(p => p.id === imageId);
    if (!image) {
        return { success: false, error: 'Sample receipt not found.' };
    }

    try {
        const response = await fetch(image.imageUrl);
        if (!response.ok) {
            throw new Error(`Failed to fetch image: ${response.statusText}`);
        }
        const imageBuffer = await response.arrayBuffer();
        const base64Image = Buffer.from(imageBuffer).toString('base64');
        const mimeType = response.headers.get('content-type') || 'image/jpeg';
        const dataUri = `data:${mimeType};base64,${base64Image}`;

        const result = await categorizeExpense({
            receiptDataUri: dataUri,
            companyPolicies: policies,
        });

        return { success: true, data: result };
    } catch (e) {
        console.error(e);
        const error = e instanceof Error ? e.message : 'An unknown error occurred.';
        return { success: false, error: `AI processing failed: ${error}` };
    }
}


export function AutomaticExpenseCategorizationDemo() {
  const [selectedReceiptId, setSelectedReceiptId] = useState(sampleReceipts[0].id);
  const [policies, setPolicies] = useState(defaultPolicies);
  const [result, setResult] = useState<CategorizeExpenseOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectedReceiptImage = PlaceHolderImages.find(p => p.id === selectedReceiptId);

  const handleSubmit = async () => {
    setIsLoading(true);
    setError(null);
    setResult(null);

    const response = await handleCategorization(selectedReceiptId, policies);

    if (response.success && response.data) {
        setResult(response.data);
    } else {
        setError(response.error || 'An unexpected error occurred.');
    }
    setIsLoading(false);
  };
  
  return (
    <div className="grid lg:grid-cols-2 gap-8 items-start">
      <Card>
        <CardHeader>
          <CardTitle>Try it Live</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
            <div className="space-y-2">
                <Label htmlFor="receipt-select">Choose a sample receipt</Label>
                <Select value={selectedReceiptId} onValueChange={setSelectedReceiptId}>
                    <SelectTrigger id="receipt-select">
                        <SelectValue placeholder="Select a receipt" />
                    </SelectTrigger>
                    <SelectContent>
                        {sampleReceipts.map(receipt => (
                            <SelectItem key={receipt.id} value={receipt.id}>{receipt.name}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>

            {selectedReceiptImage && (
                <div className="p-4 border rounded-lg bg-muted/50 flex justify-center">
                    <Image
                        src={selectedReceiptImage.imageUrl}
                        alt={selectedReceiptImage.description}
                        width={300}
                        height={450}
                        className="rounded-md shadow-md object-contain"
                        data-ai-hint={selectedReceiptImage.imageHint}
                    />
                </div>
            )}
            
            <div className="space-y-2">
                <Label htmlFor="company-policies">Company Policies (Optional)</Label>
                <Textarea
                    id="company-policies"
                    value={policies}
                    onChange={e => setPolicies(e.target.value)}
                    rows={6}
                    placeholder="e.g., Meals under ₹6000, no alcohol."
                    className="text-sm"
                />
            </div>

            <Button onClick={handleSubmit} disabled={isLoading} className="w-full">
                {isLoading ? 'Analyzing...' : 'Categorize Expense'}
            </Button>
        </CardContent>
      </Card>
      
      <Card className="lg:sticky top-24">
        <CardHeader>
          <CardTitle>AI Analysis</CardTitle>
        </CardHeader>
        <CardContent>
            {isLoading && <AnalysisSkeleton />}
            {error && (
                <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                </Alert>
            )}
            {result && <AnalysisResult result={result} />}
            {!isLoading && !error && !result && (
                 <div className="text-center text-muted-foreground py-16">
                    <Bot className="mx-auto h-12 w-12 mb-4" />
                    <p>Results will appear here after analysis.</p>
                </div>
            )}
        </CardContent>
      </Card>
    </div>
  );
}

function AnalysisSkeleton() {
    return (
        <div className="space-y-4">
            <div className="flex justify-between items-center">
                <Skeleton className="h-5 w-1/4" />
                <Skeleton className="h-5 w-1/2" />
            </div>
             <div className="flex justify-between items-center">
                <Skeleton className="h-5 w-1/4" />
                <Skeleton className="h-5 w-1/3" />
            </div>
             <div className="flex justify-between items-center">
                <Skeleton className="h-5 w-1/4" />
                <Skeleton className="h-5 w-1/3" />
            </div>
            <div className="flex justify-between items-center">
                <Skeleton className="h-5 w-1/4" />
                <Skeleton className="h-5 w-2/5" />
            </div>
            <div className="pt-2 border-t flex justify-between items-center">
                <Skeleton className="h-5 w-1/4" />
                <Skeleton className="h-8 w-1/3" />
            </div>
        </div>
    );
}

function AnalysisResult({ result }: { result: CategorizeExpenseOutput }) {
    return (
        <div className="space-y-4 text-sm">
            <ResultItem label="Merchant" value={result.merchant} />
            <ResultItem label="Date" value={result.date} />
            <ResultItem label="Amount" value={`₹${result.amount}`} />
            <ResultItem label="Category" value={result.category} />
            {result.subCategory && <ResultItem label="Sub-Category" value={result.subCategory} />}
            <div className="flex justify-between items-start pt-2 border-t">
                <span className="font-medium text-muted-foreground">Compliance</span>
                {result.isCompliant ? (
                    <Badge className="border-transparent bg-accent text-accent-foreground hover:bg-accent/80">
                        <CheckCircle2 className="mr-1 h-3 w-3" />
                        Compliant
                    </Badge>
                ) : (
                    <Badge variant="destructive">
                        <AlertTriangle className="mr-1 h-3 w-3" />
                        Violation
                    </Badge>
                )}
            </div>
            {!result.isCompliant && result.policyViolations && (
                <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-md">
                    <p className="font-semibold text-destructive">Policy Violation:</p>
                    <p className="text-destructive/90">{result.policyViolations}</p>
                </div>
            )}
        </div>
    );
}

function ResultItem({ label, value }: { label: string; value: string }) {
    return (
        <div className="flex justify-between items-center">
            <span className="font-medium text-muted-foreground">{label}</span>
            <span className="font-mono text-foreground text-right">{value}</span>
        </div>
    );
}
