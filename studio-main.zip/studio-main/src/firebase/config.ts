export const firebaseConfig = {
  "projectId": "studio-3012923399-7c970",
  "appId": "1:511842152124:web:15ee3b031b155b4b04aab9",
  "apiKey": "AIzaSyAcVlxLgeyzZb14RDBI0ZqlBxddZFLImqE",
  "authDomain": "studio-3012923399-7c970.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "511842152124"
};
