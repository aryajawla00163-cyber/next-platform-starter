import {
  Briefcase,
  Users,
  Building,
  Wrench,
  BookOpen,
  Newspaper,
  HelpCircle,
  Info,
  BriefcaseBusiness,
  HeartHandshake,
  Landmark,
  Plane,
  CreditCard,
  ScanLine,
  Receipt,
  BarChart,
  Plug,
  Star,
  CheckCircle,
  TrendingUp,
  Clock,
  Shield,
  Zap,
} from 'lucide-react';
import { type Icon } from 'lucide-react';

export const APP_NAME = 'TrackYourWallet';

type NavItem = {
  title: string;
  href: string;
  description?: string;
  items?: NavItem[];
  icon?: Icon;
};

export const NAV_LINKS: NavItem[] = [
  {
    title: 'Product',
    href: '/product',
    items: [
      { title: 'Overview', href: '/product/overview', description: "A high-level look at what's possible." },
      { title: 'Expense Management', href: '/product/expense-management', description: 'Automate expense reports and approvals.' },
      { title: 'Travel & Mileage', href: '/product/travel-mileage', description: 'Track trip expenses and mileage effortlessly.' },
      { title: 'Cards & Virtual Cards', href: '/product/cards', description: 'Issue and manage corporate cards with full control.' },
      { title: 'Receipt Scanner', href: '/product/receipt-scanner', description: 'Capture receipt data with a single photo.' },
      { title: 'AI Categorization', href: '/product/automatic-expense-categorization', icon: Zap, description: 'Let AI categorize expenses and check for policy compliance.' },
      { title: 'Bill Pay & Invoicing', href: '/product/bill-pay', description: 'Streamline your accounts payable and receivable.' },
      { title: 'Budgets & Reporting', href: '/product/budgets-reporting', description: 'Set budgets and gain real-time financial insights.' },
      { title: 'Integrations', href: '/product/integrations', description: 'Connect with your existing finance stack.' },
    ],
  },
  {
    title: 'Solutions',
    href: '/solutions',
    items: [
      { title: 'For Employees', href: '/solutions/employees', icon: Users, description: 'Submit expenses in seconds and get paid back fast.' },
      { title: 'For Small Businesses', href: '/solutions/small-business', icon: Briefcase, description: 'Simplify spending for teams of 1-9.' },
      { title: 'For Growing Teams', href: '/solutions/growing-teams', icon: Building, description: 'Scale your finance operations as you grow.' },
      { title: 'For Accountants', href: '/solutions/accountants', icon: Wrench, description: 'Automate client bookkeeping and close the books faster.' },
    ],
  },
  {
    title: 'Pricing',
    href: '/pricing',
  },
  {
    title: 'Resources',
    href: '/resources',
    items: [
      { title: 'Blog', href: '/blog', icon: Newspaper, description: 'Tips, trends, and product news.' },
      { title: 'Case Studies', href: '/case-studies', icon: BookOpen, description: 'See how companies like yours succeed.' },
      { title: 'Help Center', href: '/help-center', icon: HelpCircle, description: 'Get answers to your questions.' },
    ],
  },
  {
    title: 'Company',
    href: '/company',
    items: [
      { title: 'About', href: '/about', icon: Info, description: 'Our mission and the team behind it.' },
      { title: 'Careers', href: '/careers', icon: BriefcaseBusiness, description: 'Join us in simplifying finance.' },
      { title: 'Social Impact', href: '/social-impact', icon: HeartHandshake, description: 'How we give back to the community.' },
    ],
  },
];

export const FOOTER_LINKS = {
  product: NAV_LINKS.find(n => n.title === 'Product')?.items?.slice(1, 6) ?? [],
  solutions: NAV_LINKS.find(n => n.title === 'Solutions')?.items ?? [],
  resources: NAV_LINKS.find(n => n.title === 'Resources')?.items ?? [],
  company: NAV_LINKS.find(n => n.title === 'Company')?.items ?? [],
  legal: [
    { title: 'Privacy Policy', href: '/privacy-policy' },
    { title: 'Terms of Service', href: '/terms-of-service' },
  ],
};

export const FEATURE_GRID_ITEMS = [
  {
    icon: Receipt,
    title: 'Expense Management',
    description: 'Automate expense approvals and reporting from submission to reimbursement.',
  },
  {
    icon: Plane,
    title: 'Travel Management',
    description: 'Easily handle all travel-related expenses, from booking to on-the-road purchases.',
  },
  {
    icon: CreditCard,
    title: 'Corporate Cards',
    description: 'Issue physical and virtual cards with built-in spend controls and real-time tracking.',
  },
  {
    icon: ScanLine,
    title: 'Receipt Scanning',
    description: 'Our AI-powered scanner captures every detail from any receipt, saving hours of manual entry.',
  },
  {
    icon: Landmark,
    title: 'Global Reimbursements',
    description: 'Pay back your team in their local currency, no matter where they are in the world.',
  },
  {
    icon: Zap,
    title: 'AI Categorization',
    description: 'Let our AI automatically categorize expenses and check them against your company policies.',
  },
  {
    icon: Shield,
    title: 'Spend Controls',
    description: 'Enforce spending policies with custom rules, approval workflows, and budget limits.',
  },
  {
    icon: BarChart,
    title: 'Financial Reporting',
    description: 'Get a clear view of your company’s spending with powerful, customizable analytics.',
  },
  {
    icon: Users,
    title: 'Team Budgets',
    description: 'Create and manage budgets for departments, projects, or any custom category.',
  },
  {
    icon: Landmark,
    title: 'Bill Pay & Invoicing',
    description: 'Automate your accounts payable and create professional invoices in just a few clicks.',
  },
  {
    icon: Plug,
    title: 'Accounting Integrations',
    description: 'Sync seamlessly with popular accounting software like QuickBooks, Xero, and more.',
  },
  {
    icon: Clock,
    title: 'Automated Reports',
    description: 'Generate and schedule recurring expense reports to save your finance team valuable time.',
  },
];

export const HOW_IT_WORKS_TABS = [
  {
    title: 'Employees',
    steps: [
      { number: 1, title: 'Snap & Submit', description: 'Capture receipts with your phone. Our AI fills in the details.' },
      { number: 2, title: 'Track Everything', description: 'Monitor your expense status in real-time from the app.' },
      { number: 3, title: 'Get Reimbursed Fast', description: 'Once approved, receive payment directly to your bank account.' },
    ],
  },
  {
    title: 'Managers',
    steps: [
      { number: 1, title: 'Set Custom Rules', description: 'Define spending policies and approval chains for your team.' },
      { number: 2, title: 'Approve with a Tap', description: 'Review and approve expense reports on the go from any device.' },
      { number: 3, title: 'Monitor Team Spend', description: 'Use the dashboard to track your team’s budget and spending habits.' },
    ],
  },
  {
    title: 'Finance Teams',
    steps: [
      { number: 1, title: 'Configure Policies', description: 'Implement granular controls and ensure compliance across the company.' },
      { number: 2, title: 'Automate Syncing', description: 'Sync all expense data directly into your accounting system.' },
      { number: 3, title: 'Close Books Faster', description: 'Generate detailed reports and close the books with confidence.' },
    ],
  },
];

export const TESTIMONIALS = [
  {
    name: 'Aisha Khan',
    role: 'CFO, Innovate Inc.',
    quote: `TrackYourWallet has transformed our expense process. What used to take weeks of manual work now happens automatically. The time savings for our finance team are immense.`,
    avatarId: 'testimonial-avatar-1',
  },
  {
    name: 'David Chen',
    role: 'Sales Director, ConnectCo',
    quote: `Our sales team loves the receipt scanner. They can submit expenses from the road in seconds, which means faster reimbursements and happier employees. It's a win-win.`,
    avatarId: 'testimonial-avatar-2',
  },
  {
    name: 'Maria Garcia',
    role: 'Founder, Creative Solutions',
    quote: `As a small business owner, visibility into our spending is crucial. TrackYourWallet gives me a real-time dashboard of all expenses, so I always know where our money is going.`,
    avatarId: 'testimonial-avatar-3',
  },
];

export const FAQS = [
  {
    question: 'What is TrackYourWallet?',
    answer: 'TrackYourWallet is an all-in-one platform that simplifies every aspect of business spending. From expense reports and corporate cards to bill payments and accounting integrations, we provide the tools to control spend and automate your finance operations.',
  },
  {
    question: 'Who is it for?',
    answer: 'Our platform is designed for businesses of all sizes, from solo freelancers to large enterprises. We offer tailored solutions for employees, managers, finance teams, and accountants to meet their specific needs.',
  },
  {
    question: 'Which expenses can I track?',
    answer: 'You can track virtually any business expense, including travel, meals, software subscriptions, office supplies, and mileage. Our system is flexible enough to handle any expense category you create.',
  },
  {
    question: 'How does reimbursement work?',
    answer: 'Once an expense report is fully approved, you can initiate reimbursements directly through our platform. We support payments to bank accounts in multiple currencies, ensuring your employees get paid back quickly and accurately.',
  },
  {
    question: 'What about integrations?',
    answer: 'We integrate with a wide range of accounting, ERP, HR, and travel software, including QuickBooks, Xero, NetSuite, and more. This allows for seamless data synchronization and automates your bookkeeping.',
  },
  {
    question: 'How fast can I get started?',
    answer: 'You can sign up and start tracking expenses in minutes. Our Team plan offers a free trial, and our setup process is designed to be quick and intuitive, with no technical expertise required.',
  },
  {
    question: 'How much does it cost?',
    answer: 'We offer a range of plans to fit your needs, including a free tier for individuals. Our paid plans are typically priced per active user per month. Visit our Pricing page for detailed information.',
  },
];

export const PRICING_TIERS = [
  {
    name: 'Starter',
    price: 'Free',
    priceDetail: 'For individuals & freelancers',
    features: [
      'Up to 25 receipt scans per month',
      'Basic expense reports',
      'Standard currency support',
      'Community support',
    ],
    cta: 'Get Started',
    ctaHref: '/signup',
  },
  {
    name: 'Team',
    price: '₹1000',
    priceDetail: 'per active user / month',
    features: [
      'Unlimited receipt scans',
      'Multi-level approval workflows',
      'Basic policy enforcement',
      'Accounting integrations (QuickBooks, Xero)',
      'Team dashboards & reporting',
      'Priority email support',
    ],
    cta: 'Start Free Trial',
    ctaHref: '/signup?plan=team',
    isPopular: true,
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    priceDetail: 'For larger organizations',
    features: [
      'Everything in Team, plus:',
      'Corporate card management',
      'Advanced policy controls & compliance',
      'Custom roles and permissions',
      'ERP integrations (NetSuite, SAP)',
      'Single Sign-On (SSO)',
      'Dedicated account manager',
    ],
    cta: 'Contact Sales',
    ctaHref: '/contact',
  },
];

export const INTEGRATION_LOGOS = [
  { name: 'Accounting Tool A', icon: Landmark },
  { name: 'Accounting Tool B', icon: Landmark },
  { name: 'HR Platform', icon: Users },
  { name: 'ERP System', icon: Building },
  { name: 'Travel Partner', icon: Plane },
  { name: 'Collaboration App', icon: Wrench },
];

export const COMPANY_LOGOS = [
  { name: 'Innovate Inc.' },
  { name: 'ConnectCo' },
  { name: 'Creative Solutions' },
  { name: 'Global Tech' },
  { name: 'Synergy Corp' },
];

export const APP_SIDEBAR_LINKS: NavItem[] = [
  { title: 'Dashboard', href: '/dashboard', icon: BarChart },
  { title: 'Expenses', href: '/dashboard/expenses', icon: Receipt },
  { title: 'Cards', href: '/dashboard/cards', icon: CreditCard },
  { title: 'Approvals', href: '/dashboard/approvals', icon: CheckCircle },
  { title: 'Reports', href: '/dashboard/reports', icon: TrendingUp },
  { title: 'Settings', href: '/dashboard/settings', icon: Wrench },
];
