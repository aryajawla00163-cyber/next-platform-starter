
export type Expense = {
  id: string;
  userId: string;
  amount: number;
  date: string; // Should be ISO string
  category: string;
  status: 'Pending' | 'Approved' | 'Flagged' | 'Rejected';
  merchant: string;
  description: string;
  receiptImageURL?: string;
};

export type NewExpense = Omit<Expense, 'id' | 'userId' | 'status'>;

export type EditableExpense = Omit<Expense, 'id' | 'userId' | 'status'>;
